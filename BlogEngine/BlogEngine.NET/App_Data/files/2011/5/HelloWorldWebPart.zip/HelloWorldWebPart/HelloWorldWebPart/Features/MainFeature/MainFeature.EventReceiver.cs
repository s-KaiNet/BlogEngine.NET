using System.Runtime.InteropServices;
using Microsoft.SharePoint;
using System.Linq;

namespace HelloWorldWebPart.Features.MainFeature
{
    [Guid("ba2bb853-61c4-4002-82ae-165fcb8c7032")]
    public class MainFeatureEventReceiver : SPFeatureReceiver
    {
        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            var rootWeb = ((SPSite) properties.Feature.Parent).RootWeb;
            var wpToDelete =
                rootWeb.Lists["Web Part Gallery"].Items.Cast<SPListItem>().Where(
                    n => n.File.Name.Contains("HelloWorldWebPart")).Select(w => w.File).ToList();
            foreach (var wp in wpToDelete)
            {
                wp.Delete();
            }
        }
    }
}
