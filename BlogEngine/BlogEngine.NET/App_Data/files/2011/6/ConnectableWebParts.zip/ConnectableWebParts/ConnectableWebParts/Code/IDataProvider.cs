﻿
namespace ConnectableWebParts.Code
{
    public interface IDataProvider
    {
        string Name { get; }
    }
}
