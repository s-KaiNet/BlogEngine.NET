﻿using System.ComponentModel;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace HelloWorldWebPart.WebParts.HelloWorldWebPart2
{
    [ToolboxItemAttribute(false)]
    public class HelloWorldWebPart2 : WebPart
    {
        protected override void CreateChildControls()
        {
            var lblHello = new Label {Text = "Hello world"};
            Controls.Add(lblHello);
        }
    }
}
