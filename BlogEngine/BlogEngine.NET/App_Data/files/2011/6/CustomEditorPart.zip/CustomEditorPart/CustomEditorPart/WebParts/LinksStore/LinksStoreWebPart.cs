﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Web.UI.WebControls.WebParts;
using CustomEditorPart.Controls;
using CustomEditorPart.CONTROLTEMPLATES.CustomEditorPartSample;

namespace CustomEditorPart.WebParts.LinksStore
{
    public enum Seasons
    {
        Spring = 0,
        Autumn,
        Winter,
        Summer
    }

    [ToolboxItemAttribute(false)]
    public class LinksStoreWebPart : WebPart
    {
        private const string _ascxPath = @"~/_CONTROLTEMPLATES/CustomEditorPartSample/LinksStoreUserControl.ascx";

        private int _pageSize = 4;
        [WebBrowsable(true),
        WebDisplayName("Page Size"),
        WebDescription("set the page size"),
        Category("Custom settings"),
        Personalizable(PersonalizationScope.User)]
        public int PageSize
        {
            get { return _pageSize; }
            set { _pageSize = value; }
        }

        [WebBrowsable(true),
         WebDisplayName("Editable"),
         Category("Custom settings"),
         WebDescription("settings that allow you to edit web part"),
         Personalizable(PersonalizationScope.User)]
        public bool Editable
        {
            get;
            set;
        }

        [WebBrowsable(true),
         WebDisplayName("Greetings"),
         WebDescription("user greetings"),
         Category("Custom settings"),
         Personalizable(PersonalizationScope.User)]
        public string Greetings
        {
            get;
            set;
        }

        [WebBrowsable(true),
         WebDisplayName("CurrentDate"),
         Category("Custom settings"),
         WebDescription("gets the current date"),
         Personalizable(PersonalizationScope.User)]
        public DateTime CurrentDate
        {
            get;
            set;
        }

        [WebBrowsable(true),
         WebDisplayName("Season"),
         WebDescription("gets the current season"),
         Category("Custom settings"),
         Personalizable(PersonalizationScope.User)]
        public Seasons Season
        {
            get;
            set;
        }

        [WebBrowsable(true),
         WebDisplayName("Settings"),
         WebDescription("some settings store"),
         Category("Custom settings"),
         Personalizable(PersonalizationScope.User)]
        public List<string> Settings
        {
            get;
            set;
        }

        protected override void CreateChildControls()
        {
            var control = (LinksStoreUserControl)Page.LoadControl(_ascxPath);
            if (control != null)
            {
                control.PageSize = PageSize;
                control.Editable = Editable;
                control.Greetings = Greetings;
                control.CurrentDate = CurrentDate;
                control.Season = Season;
                control.Settings = Settings;
                Controls.Add(control);
            }
        }

        public override EditorPartCollection CreateEditorParts()
        {
            var editorParts = new List<EditorPart>(1);
            var editor = new LinksStoreEditorPart();
            editor.ID = ID + "LinksStoreEditorPart"; // required!  - System.InvalidOperationException: EditorPart does not have an ID.   
            editor.Title = "Links Store custom editor part.";
            editorParts.Add(editor);
            return new EditorPartCollection(base.CreateEditorParts(), editorParts);
        }

    }
}
