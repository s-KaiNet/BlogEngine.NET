﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace HelloWorldVisualWebPart.CONTROLTEMPLATES.HelloWorldVisualWebPart
{
    public partial class AnotherUserControl : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}
