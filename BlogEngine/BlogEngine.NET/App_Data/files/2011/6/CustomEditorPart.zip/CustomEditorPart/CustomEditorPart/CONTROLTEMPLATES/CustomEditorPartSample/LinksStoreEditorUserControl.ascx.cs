﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Linq;
using CustomEditorPart.Entity;

namespace CustomEditorPart.CONTROLTEMPLATES.CustomEditorPartSample
{
    public partial class WebPartEditorControl : UserControl
    {
        public List<string> Titles
        {
            set
            {
                if (value == null) return;
                rptLinks.DataSource = value.Select(v => new LinkEntity{Title = v}).ToList();
                rptLinks.DataBind();
            }
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            rptLinks.ItemCommand += OntemCommand;
        }

        protected void AddEntry(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtNewEntry.Text))
            {
                var entities = GetData();
                entities.Add(txtNewEntry.Text);
                Titles = entities;
            }
        }

        public List<string> GetData()
        {
            var ent = new List<string>();
            foreach (RepeaterItem item in rptLinks.Items)
            {
                var label = (Label)item.FindControl("lblTitle");
                if (label != null)
                {
                    ent.Add(label.Text);
                }
            }
            return ent;
        }

        private void OntemCommand(object source, RepeaterCommandEventArgs e)
        {
            if (e.CommandName == "Delete")
            {
                var entities = GetData();
                entities.Remove((string)e.CommandArgument);
                Titles = entities;
            }
        }
    }
}
