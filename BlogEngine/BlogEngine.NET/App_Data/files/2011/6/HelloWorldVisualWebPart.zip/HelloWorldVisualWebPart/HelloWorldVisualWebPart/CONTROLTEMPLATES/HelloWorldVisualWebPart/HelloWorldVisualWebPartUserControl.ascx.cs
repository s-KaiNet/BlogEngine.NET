﻿using System;
using System.Web.UI;
using Microsoft.SharePoint;

namespace HelloWorldVisualWebPart.WebParts.HelloWorldVisualWebPart
{
    public partial class HelloWorldVisualWebPartUserControl : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            var web = SPContext.Current.Web;
            lblWebTitle.Text = web.Title;
        }

        protected void ChangeTitle(object sender, EventArgs e)
        {
            var web = SPContext.Current.Web;
            web.Title = txtNewTitle.Text;
            lblWebTitle.Text = txtNewTitle.Text;
            web.Update();
        }
    }
}
