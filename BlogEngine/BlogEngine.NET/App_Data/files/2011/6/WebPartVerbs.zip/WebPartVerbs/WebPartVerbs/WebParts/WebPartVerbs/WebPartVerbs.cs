﻿using System;
using System.ComponentModel;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint.WebControls;

namespace WebPartVerbs.WebParts.WebPartVerbs
{
    [ToolboxItemAttribute(false)]
    public class WebPartVerbs : WebPart
    {
        private Label lblTime;

        protected override void CreateChildControls()
        {
            ScriptLink.RegisterScriptAfterUI(Page, "WebPartVerbs/webpartverbs.js", false);

            lblTime = new Label { Text = DateTime.Now.ToShortTimeString() };
            Controls.Add(lblTime);
        }

        protected override void RenderContents(HtmlTextWriter writer)
        {
            writer.AddAttribute(HtmlTextWriterAttribute.Id, "wp_verbs");
            writer.RenderBeginTag(HtmlTextWriterTag.Div);
            writer.Write("Server time is:");
            writer.RenderBeginTag(HtmlTextWriterTag.Br);
            writer.RenderEndTag();
            lblTime.RenderControl(writer);
            writer.RenderEndTag();
        }

        public override WebPartVerbCollection Verbs
        {
            get
            {
                var clientVerb = new WebPartVerb(ID + "clientVerb", "ClientVerbClick()") { Text = "Change web part color" };
                var serverVerb = new WebPartVerb(ID + "serverVerb", GetServerTime) { Text = "Get server time" };
                var combinedVerb = new WebPartVerb(ID + "comboVerb", GetServerTime, "CheckIfAllowed()") { Text = "Get time with condition script" };
                var verbs = new[] { clientVerb, serverVerb, combinedVerb };
                return new WebPartVerbCollection(base.Verbs, verbs);
            }
        }

        private void GetServerTime(object sender, WebPartEventArgs e)
        {
            EnsureChildControls();
            lblTime.Text = DateTime.Now.ToLongTimeString();
        }
    }
}
