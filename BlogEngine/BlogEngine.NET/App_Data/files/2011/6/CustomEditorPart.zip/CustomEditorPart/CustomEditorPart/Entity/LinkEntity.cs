﻿namespace CustomEditorPart.Entity
{
    public class LinkEntity
    {
        public string Title { get; set; }
    }
}
