﻿using System.ComponentModel;
using System.Web.UI;
using System.Web.UI.WebControls.WebParts;

namespace HowToAddWebPart.WebParts.SampleWebPart
{
    [ToolboxItemAttribute(false)]
    public class SampleWebPart : WebPart
    {
        protected override void CreateChildControls()
        {
            Controls.Add(new LiteralControl("Hi from web part!"));
        }
    }
}
