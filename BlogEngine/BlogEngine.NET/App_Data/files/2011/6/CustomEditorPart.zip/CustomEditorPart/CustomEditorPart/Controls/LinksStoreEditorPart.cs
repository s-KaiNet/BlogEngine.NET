﻿using System.Web.UI.WebControls.WebParts;
using CustomEditorPart.CONTROLTEMPLATES.CustomEditorPartSample;
using CustomEditorPart.WebParts.LinksStore;

namespace CustomEditorPart.Controls
{
    public class LinksStoreEditorPart : EditorPart
    {
        private const string PathToEditorUserControl = "~/_controltemplates/CustomEditorPartSample/LinksStoreEditorUserControl.ascx";

        private WebPartEditorControl _editorControl;

        protected override void CreateChildControls()
        {
            _editorControl = (WebPartEditorControl) Page.LoadControl(PathToEditorUserControl);
            Controls.Add(_editorControl);
        }

        //transfer settings from editor part to our web part
        public override bool ApplyChanges()
        {
            EnsureChildControls();
            var wp = (LinksStoreWebPart) WebPartToEdit;
            wp.Settings = _editorControl.GetData();
            return true;
        }

        //transfer settings from web part to editor part
        public override void SyncChanges()
        {
            EnsureChildControls();
            var wp = (LinksStoreWebPart)WebPartToEdit;
            _editorControl.Titles = wp.Settings;
        }
    }
}
