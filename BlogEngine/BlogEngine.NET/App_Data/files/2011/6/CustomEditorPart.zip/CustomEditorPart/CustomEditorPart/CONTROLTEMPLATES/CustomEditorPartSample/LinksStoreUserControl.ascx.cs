﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using CustomEditorPart.WebParts.LinksStore;

namespace CustomEditorPart.CONTROLTEMPLATES.CustomEditorPartSample
{
    public partial class LinksStoreUserControl : UserControl
    {
        public int PageSize
        {
            get; set;
        }

        public bool Editable
        {
            get; set;
        }

        public string Greetings
        {
            get; set;
        }

        public DateTime CurrentDate
        {
            get; set;
        }

        public Seasons Season
        {
            get; set;
        }

        public List<string> Settings
        {
            get; set;
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            lblDate.Text = CurrentDate.ToShortTimeString();
            lblEditable.Text = Editable.ToString();
            lblGreetings.Text = Greetings;
            lblPageSize.Text = PageSize.ToString();
            switch(Season)
            {
                case Seasons.Autumn:
                    lblSeason.Text = "Autumn";
                    break;
                case Seasons.Spring:
                    lblSeason.Text = "Spring";
                    break;
                case Seasons.Summer:
                    lblSeason.Text = "Summer";
                    break;
                case Seasons.Winter:
                    lblSeason.Text = "Winter";
                    break;
            }
            if(Settings != null)
            {
                lblSettings.Text = string.Join(", ", Settings.ToArray());
            }
        }
    }
}
