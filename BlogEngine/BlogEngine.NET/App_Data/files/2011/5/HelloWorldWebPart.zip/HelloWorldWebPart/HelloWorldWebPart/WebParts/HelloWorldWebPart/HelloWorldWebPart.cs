﻿using System;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace HelloWorldWebPart.WebParts.HelloWorldWebPart
{
    [ToolboxItemAttribute(false)]
    public class HelloWorldWebPart : WebPart
    {
        protected override void RenderContents(HtmlTextWriter writer)
        {
            writer.Write("Hello world");
        }
    }
}
