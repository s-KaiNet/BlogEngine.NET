﻿using System.ComponentModel;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using ConnectableWebParts.Code;

namespace ConnectableWebParts.WebParts.WPConsumer
{
    [ToolboxItemAttribute(false)]
    public class WPConsumer : WebPart
    {
        private IDataProvider _dataProvider;
        private Label lblGreetings;

        protected override void CreateChildControls()
        {
            lblGreetings = new Label();
            if(_dataProvider != null)
            {
                lblGreetings.Text = string.Format("Hi, {0}", _dataProvider.Name);
            }
            else
            {
                lblGreetings.Text = "No connection. :)";
            }
            Controls.Add(lblGreetings);
        }

        [ConnectionConsumer("Data provider", "wpDataConsumer", AllowsMultipleConnections = false)]
        public void DataConnectionPoint(IDataProvider provider)
        {
            _dataProvider = provider;
        }
    }
}
