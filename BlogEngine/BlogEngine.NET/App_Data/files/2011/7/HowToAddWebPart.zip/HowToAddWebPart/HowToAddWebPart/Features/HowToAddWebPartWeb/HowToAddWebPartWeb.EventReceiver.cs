using System.Runtime.InteropServices;
using System.Web.UI.WebControls.WebParts;
using HowToAddWebPart.WebParts.SampleWebPart;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;

namespace HowToAddWebPart.Features.HowToAddWebPartWeb
{
    [Guid("f07c1910-0463-4149-910a-6c2e471b4917")]
    public class HowToAddWebPartWebEventReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            var web = properties.Feature.Parent as SPWeb;
            if(web != null)
            {
                var manager = web.GetLimitedWebPartManager(
                    SPUrlUtility.CombineUrl(web.Url, "SitePage/WebPartPage.aspx"), PersonalizationScope.Shared);
                var webPart = new SampleWebPart();
                webPart.Title = "Sample WebPart - using Feature receiver";
                manager.AddWebPart(webPart, "Left", 1);
            }
        }
    }
}
