﻿using System.ComponentModel;
using System.Web.UI;
using System.Web.UI.WebControls.WebParts;

namespace HelloWorldVisualWebPart.WebParts.HelloWorldVisualWebPart
{
    [ToolboxItemAttribute(false)]
    public class HelloWorldVisualWebPart : WebPart
    {
        private const string userControlPath = @"~/_CONTROLTEMPLATES/HelloWorldVisualWebPart/HelloWorldVisualWebPartUserControl.ascx";
        private const string anotherControlPath = @"~/_CONTROLTEMPLATES/HelloWorldVisualWebPart/AnotherUserControl.ascx";

        private Control userControl;
        private Control anotherControl;

        protected override void CreateChildControls()
        {
            userControl = Page.LoadControl(userControlPath);
            anotherControl = Page.LoadControl(anotherControlPath);
            Controls.Add(userControl);
            Controls.Add(anotherControl);
        }

        protected override void RenderContents(HtmlTextWriter writer)
        {
            writer.AddAttribute(HtmlTextWriterAttribute.Id, "wrapper");
            writer.RenderBeginTag(HtmlTextWriterTag.Div);
            anotherControl.RenderControl(writer);
            userControl.RenderControl(writer);
            writer.RenderEndTag();
        }
    }
}
