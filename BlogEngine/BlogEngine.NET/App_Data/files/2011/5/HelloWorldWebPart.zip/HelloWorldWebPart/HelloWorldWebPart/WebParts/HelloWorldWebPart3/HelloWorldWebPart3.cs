﻿using System;
using System.ComponentModel;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace HelloWorldWebPart.WebParts.HelloWorldWebPart3
{
    [ToolboxItemAttribute(false)]
    public class HelloWorldWebPart3 : WebPart
    {
        protected TextBox _txtName;
        protected Button _btnSave;


        protected override void CreateChildControls()
        {
            _txtName = new TextBox();
            _btnSave = new Button {Text = "Save"};
            _btnSave.Click += btnSaveClick;
            Controls.Add(_btnSave);
            Controls.Add(_txtName);
        }

        private void btnSaveClick(object sender, EventArgs e)
        {
            //some code here
        }

        protected override void RenderContents(HtmlTextWriter writer)
        {
            writer.RenderBeginTag(HtmlTextWriterTag.Div);
            writer.Write("Please, enter your name:");
            _txtName.RenderControl(writer);
            writer.RenderBeginTag(HtmlTextWriterTag.Br);
            writer.RenderEndTag();
            _btnSave.RenderControl(writer);
            writer.RenderEndTag();
        }
    }
}
