﻿function ClientVerbClick() {
    var el = document.getElementById("wp_verbs");
    var r = Math.floor(Math.random() * 255);
    var g = Math.floor(Math.random() * 255);
    var b = Math.floor(Math.random() * 255);
    el.style.color = 'rgb(' + r +',' + g + ',' + b + ')';
}

function CheckIfAllowed() {
    alert("after you click 'OK' server code will execute");
}