﻿using System;
using System.ComponentModel;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using ConnectableWebParts.Code;

namespace ConnectableWebParts.WebParts.WPProvider
{
    [ToolboxItemAttribute(false)]
    public class WPProvider : WebPart, IDataProvider
    {
        [WebBrowsable(true), 
        WebDisplayName("Name"),
        Personalizable(PersonalizationScope.User)]
        public string SomeName { set; get; }

        protected override void CreateChildControls()
        {
            var lblName = new Label {Text = string.Format("Hi, my name is {0}", SomeName)};
            Controls.Add(lblName);
        }

        public string Name
        {
            get { return SomeName; }
        }

        [ConnectionProvider("Data provider", "wpDataProvider", AllowsMultipleConnections = true)]
        public IDataProvider DataProviderConnectionPoint()
        {
            return this;
        }
    }
}
