param([string]$path)
Add-PSSnapin Microsoft.SharePoint.PowerShell -EA SilentlyContinue
. ($path + "\functions.ps1")
$siteUrl = "http://localhost/sites/test"
Write-Host $path
#Add groups
AddGroups $siteUrl ($path + "\Resources\Groups.xml")